public class Ekspresi {

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        /* KAMUS */
        int x = 1;
        int y = 2;
        /* ALGORITMA */
        System.out.print("x = "+ x + "\n");
        System.out.print("y = "+ y + "\n");
        System.out.print("hasil ekspresi = (x<y)?x:y = "+ ((x < y) ? x : y)); 
        /*Gunakan dalam kurung "(statement dan kondisi)" untuk menyatakan satu kesatuan pernyataan*/
    }
}
