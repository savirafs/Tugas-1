public class Asgdll {

    /**
     * @param args
     */

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        /* Kamus */
        float f=20.0f;
        double fll;

        /* Algoritma */
        fll= 10.0f;
        System.out.println("f : " +f+ "\nfll: " +fll);
    }

}
