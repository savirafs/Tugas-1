public class Asign {

    /**
     * @param args
     */


    public static void main(String[] args) {
        // TODO Auto-generated method stub
        /* kamus */
        int i;
        /* Program */
        System.out.print("hello\n"); i=5;
        System.out.println("Ini nilai i : " +i);
    }

}
